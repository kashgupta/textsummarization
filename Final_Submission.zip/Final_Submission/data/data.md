We used unsupervised and supervised methods, so we did not use validation sets on some occasions.
The files are large, so in this folder you will find the samples that we used.

The complete data set/files needed to run simple-baseline.py and score.py can be found at https://drive.google.com/file/d/1I00XpcAUCbEgqpmR13Sp8_UcnOXzlQjP/view?usp=sharing
