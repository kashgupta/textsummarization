The folder for the code has 5 folders inside it.
One for the simple baseline (same as previously submitted)
One for Milestone 3 (published baseline, same as previously submitted)
One for Milestone 4 - Extension 1 (first extension, same as previously submitted)
One for Extensions 2, 3 and 4, each.

Each folder has the corresponding files needed to run the code, and score the outputs.

The folder called extra shows the code to obtain the max possible rouge-score per article.